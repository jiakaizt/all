#encoding=utf-8
import numpy as np
import util
from models import decompose
import eval
from naive_MLP_forecasting import MLP_forecasting
from naive_SVR_forecasting import SVR_forecasting
from naive_RNN_forecasting import RNN_forecasting
from naive_RNN_forecasting import RNN_forecasting1
import time
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
import warnings
warnings.filterwarnings("ignore")


def decompose_RNN_forecasting(ts, ts1, ts2, ts3, data, trend, seasonal, redidual, freq, lag, epoch=20, hidden_num=64,
                              batch_size=32, lr=1e-3, unit="GRU", varFlag=False, maxLen=48, minLen=24, step=8):


    print("trend shape:", trend.shape)
    print("peroid shape:", seasonal.shape)
    print("residual shape:", residual.shape)
    

    # 分别预测decomposition
    resWin = trendWin = lag
    
    
    #####hybrid model,可以直接使用该模块进行模型组合，运行代码，也可以使用单独的分解模型。
    trTrain, trTest, MAE1, MRSE1, SMAPE1 = SVR_forecasting(trend, lookBack=lag, C=0.1, epsilon=0.01)
    resTrain, resTest, MAE2, MRSE2, SMAPE2 = SVR_forecasting(residual, lookBack=lag, C=0.1, epsilon=0.01)
    
   # trTrain, trTest, MAE1, MRSE1, SMAPE1 = MLP_forecasting(trend, inputDim=lag, hiddenNum=hidden_dim, lr=lr, epoch=epoch, batchSize=batch_size, plot_flag=True)
   # resTrain, resTest, MAE2, MRSE2, SMAPE2 = MLP_forecasting(residual, inputDim=lag, hiddenNum=hidden_dim, lr=lr, epoch=epoch, batchSize=batch_size, plot_flag=True)
    
    #trTrain, trTest, MAE1, MRSE1, SMAPE1 = RNN_forecasting1(trend, lookBack=lag, epoch=epoch, batchSize=batch_size, hiddenNum=hidden_num, 
     #                                                      varFlag=varFlag, minLen=minLen, maxLen=maxLen, step=step, unit=unit1, lr=lr)
   # trTrain, trTest, MAE1, MRSE1, SMAPE1 = RNN_forecasting(trend, lookBack=lag, epoch=epoch, batchSize=batch_size, hiddenNum=hidden_num, 
   #                                                        varFlag=varFlag, minLen=minLen, maxLen=maxLen, step=step, unit=unit, lr=lr)                                                                                               
   # resTrain, resTest, MAE2, MRSE2, SMAPE2 = RNN_forecasting(residual, lookBack=lag, epoch=epoch, batchSize=batch_size, hiddenNum=hidden_num,
    #                                         varFlag=varFlag, minLen=minLen, maxLen=maxLen, step=step, unit=unit, lr=lr)
                                            
    print("trTrain shape:", trTrain.shape)
    print("resTrain shape:", resTrain.shape)
    print("trTest shape:", trTest.shape)
    print("resTest shape:", resTest.shape)


    # 数据对齐
    trendPred, resPred = util.align(trTrain, trTest, trendWin, resTrain, resTest, resWin)
    print("trendPred shape is", trendPred.shape)
    print("resPred shape is", resPred.shape)

    # 获取最终预测结果

    trainPred = trTrain+seasonal[lag:lag+trTrain.shape[0]]+resTrain
    testPred = trTest+seasonal[2*resWin+resTrain.shape[0]:]+resTest
    

    # 获得ground-truth数据
        
    data = data[:]
    trainY = data[trendWin:trendWin+trTrain.shape[0]]
    testY = data[2*resWin+resTrain.shape[0]:]#数据长度

    #trend子序列的原始序列长度（去除lag）
    trTrainY = trend[trendWin:trendWin+trTrain.shape[0]]
    trTestY = trend[2*trendWin+trTrain.shape[0]:]
    
    #residual子序列的原始序列长度（去除lag）
    resTrainY = residual[trendWin:trendWin+trTrain.shape[0]]
    resTestY = residual[2*trendWin+trTrain.shape[0]:]
    

    # 评估指标
    MAE = eval.calcMAE(testY, testPred)
    print( MAE)
    RMSE = eval.calcRMSE(testY, testPred)
    print(RMSE)
    MAPE = eval.calcMAPE(testY, testPred)
    print(MAPE)
    SMAPE = eval.calcSMAPE(testY, testPred)
    print(SMAPE)
    

    
#趋势子序列预测结果可视化
    plt.figure(figsize=(20, 8))
    plt.xticks(fontsize=22)
    plt.yticks(fontsize=22)
    plt.xlabel(u"Number of Samples", size=28) #x轴标签
    plt.ylabel(" trend subsequence (%)",size=28) #Y轴标签     
    
    gtruth = np.concatenate((trTrainY,  trTestY))
    plt.plot(gtruth,c='b', label= 'Original', linewidth=2)
    plt.plot([x for x in trTrain],c='g', label='Predicted training set', linewidth=2)
    plt.plot([None for _ in trTrain]+[x for x in trTest],c='r', label='Predicted test set', linewidth=2)
    plt.legend(loc='upper left', fontsize='xx-large')
    plt.show()
    
    
   
#残差子序列预测结果可视化
    plt.figure(figsize=(20, 8))
    plt.xticks(fontsize=22)
    plt.yticks(fontsize=22)
    plt.xlabel(u"Number of Samples", size=28) #x轴标签
    plt.ylabel("residual subsequence (%)",size=28) #Y轴标签 
    
  
    gtruth = np.concatenate((resTrainY,  resTestY))
    plt.plot(gtruth,c='b', label= 'Original',linewidth=2)
    plt.plot([x for x in resTrain],c='g',label='Predicted training set', linewidth=2)
    plt.plot([None for _ in resTrain]+[x for x in resTest],c='r', label='Predicted test set', linewidth=2)
    plt.legend(loc='upper left', fontsize='xx-large')
    plt.show()
    
    
  #最终预测结果可视化  
    plt.figure(figsize=(20, 8))
    plt.xticks(fontsize=22)
    plt.yticks(fontsize=22)
    plt.xlabel(u"Number of Samples", size=28) #x轴标签
    plt.ylabel("Memory Utilization (%)",size=28) #Y轴标签
    
    gtruth = np.concatenate((trainY, testY))
    plt.plot(gtruth,c='b', label= 'Original', linewidth=2)
    plt.plot([x for x in trainPred],c='g', label='Predicted training set',linewidth=2)
    plt.plot([None for _ in trainPred]+[x for x in testPred],c='r', label='Predicted test set', linewidth=2)
    plt.legend(loc='upper left', fontsize='xx-large')
    plt.show()
    


    return trainPred, testPred, MAE, RMSE, SMAPE


if __name__ == "__main__":

    lag = 24# if using varFlag, lag == maxLen
    batch_size = 32
    epoch = 50
    hidden_dim = 64
    unit = "GRU"
    unit1 = "LSTM"
    
    lr = 1e-4
    freq = 18
    varFlag = True
    minLen = lag
    maxLen = lag
    step = 3

#####################   1     ##################################
    ts, data = util.load_data("./data/IoTdata2.csv", columnName="Mem")
    
    ts1, trend = util.load_data("./data/18/sub2.csv", columnName="trend")
    ts2, seasonal = util.load_data("./data/18/sub2.csv", columnName="seasonal")
    ts3, residual = util.load_data("./data/18/sub2.csv", columnName="remainder")
   # print (trend)
#######################################################################
    trainPred, testPred, mae, rmse, smape = decompose_RNN_forecasting(ts, ts1, ts2, ts3, data, trend, seasonal, residual, lag=lag, freq=freq, unit=unit,
                                                                      varFlag=varFlag, minLen=minLen, maxLen=maxLen, step=step, epoch=epoch, hidden_num=hidden_dim, lr=lr, batch_size=batch_size)





# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt
from pylab import * 
import util
import numpy as np
mpl.rcParams['font.sans-serif'] = ['SimHei']

#names = 288
x = range(288)

# #可以采取这种形式，将所有的方法的288条拟合结果放到一个表里，加上表头
ts, DGRU = util.load_data("./data/Ex2-1.csv", columnName="DGRU")

ts, GRU = util.load_data("./data/Ex2-1.csv", columnName="GRU")   
ts, LSTM = util.load_data("./data/Ex2-1.csv", columnName="LSTM")
ts, MLP = util.load_data("./data/Ex2-1.csv", columnName="MLP")
ts, SVR = util.load_data("./data/Ex2-1.csv", columnName="SVR")
ts, ARIMA = util.load_data("./data/Ex2-1.csv", columnName="ARIMA")
ts, Original = util.load_data("./data/Ex2-1.csv", columnName="Original")

#freq = 24*60//30*1
#MAE


plt.figure(figsize=(20, 8), dpi=600)

plt.ylim(50, 78)#
#plt.plot(x, DGRU, 'r--', linewidth=1, label='DGRU')
plt.plot(x, GRU, 'y--', linewidth=1, label='GRU')
plt.plot(x, LSTM, 'g--', linewidth=1, label='LSTM')
plt.plot(x, MLP, 'b--', linewidth=1, label='MLP')
plt.plot(x, SVR, 'm--', linewidth=1, label='SVR')
plt.plot(x, ARIMA, 'c--', linewidth=1, label='ARIMA')
plt.plot(x, Original, 'k-', linewidth=1, label='Original')
plt.plot(x, DGRU, 'r--', linewidth=1, label='DGRU')



#可以采取这种形式，将所有的方法的288条拟合结果放到一个表里，加上表头
# ts, DGRU = util.load_data("./data/Ex3-1.csv", columnName="DGRU")

# ts, DLSTM = util.load_data("./data/Ex3-1.csv", columnName="DLSTM")
# ts, DMLP = util.load_data("./data/Ex3-1.csv", columnName="DMLP")
# ts,DSVR = util.load_data("./data/Ex3-1.csv", columnName="DSVR")
# ts,SVRLSTM = util.load_data("./data/Ex3-1.csv", columnName="SVRLSTM")
# ts,SVRGRU = util.load_data("./data/Ex3-1.csv", columnName="SVRGRU")
# ts, Original = util.load_data("./data/Ex3-1.csv", columnName="Original")
# # #freq = 24*60//30*1
# # #MAE




# plt.figure(figsize=(20, 8),dpi = 600)

# plt.ylim(35, 50)# 需调整

# plt.plot(x, DLSTM, 'y--', linewidth=1, label='DLSTM')
# plt.plot(x, DMLP, 'g--', linewidth=1, label='DMLP')
# plt.plot(x, DSVR, 'b--', linewidth=1, label='DSVR')
# plt.plot(x, SVRLSTM, 'm--', linewidth=1, label='SVR-LSTM')
# plt.plot(x, SVRGRU, 'c--', linewidth=1, label='SVR-GRU')
# plt.plot(x, Original, 'k-', linewidth=1, label='Original')
# plt.plot(x, DGRU, 'r--', linewidth=1, label='DGRU')



plt.legend(loc='lower right',fontsize='xx-large')  # 让图例生效
plt.tick_params(labelsize=22)
plt.margins(0)
plt.subplots_adjust(bottom=0.15)
plt.xlabel(u"Number of Samples", size=28) #x轴标签
plt.ylabel("Memory Utilization (%)",size=28) #Y轴标签
#plt.title("Comparable Results of MAPE",size=32) #标题

plt.show()
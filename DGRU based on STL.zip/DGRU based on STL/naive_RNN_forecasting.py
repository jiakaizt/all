#encoding=utf-8

from models import RNNs
import util
import eval
from sklearn.preprocessing import MinMaxScaler
import matplotlib.pyplot as plt
import csv
import numpy as np
import pandas as pd


def RNN_forecasting(dataset, lookBack, lr, inputDim=1, hiddenNum=64, outputDim=1, unit="GRU", epoch=20,
                    batchSize=30, varFlag=False, minLen=15, maxLen=30, step=5):

    # 归一化数据
    scaler = MinMaxScaler(feature_range=(0, 1))
    dataset = scaler.fit_transform(dataset)

    # 分割序列为样本,并整理成RNN的输入形式
    train, test = util.divideTrainTest(dataset)

    trainX = None
    trainY = None
    vtrainX = None
    vtrainY = None
    testX = None
    testY = None
    vtestX = None
    vtestY = None

    # 构建模型并训练
    RNNModel = RNNs.RNNsModel(inputDim, hiddenNum, outputDim, unit, lr)
    print ("model:", inputDim, outputDim)
    if varFlag:
        vtrainX, vtrainY = util.createVariableDataset(train, minLen, maxLen, step)
        vtestX, vtestY = util.createVariableDataset(test, minLen, maxLen, step)
        print("trainX shape is", vtrainX.shape)
        print("trainY shape is", vtrainY.shape)
        print("testX shape is", vtestX.shape)
        print("testY shape is", vtestY.shape)
        RNNModel.train(vtrainX, vtrainY, epoch, batchSize)
    else:
        trainX, trainY = util.createSamples(train, lookBack)
        testX, testY = util.createSamples(test, lookBack)
        print("trainX shape is", trainX.shape)
        print("trainY shape is", trainY.shape)
        print("testX shape is", testX.shape)
        print("testY shape is", testY.shape)
        RNNModel.train(trainX, trainY, epoch, batchSize)

    # 预测
    if varFlag:
        trainPred = RNNModel.predictVarLen(vtrainX, minLen, maxLen, step)
        testPred = RNNModel.predictVarLen(vtestX, minLen, maxLen, step)
        trainPred= trainPred.reshape(-1, 1)
    else:
        trainPred = RNNModel.predict(trainX)
        testPred = RNNModel.predict(testX)
        trainPred = trainPred.reshape(-1, 1)

    if varFlag:
        # 转化一下test的label
        testY = util.transform_groundTruth(vtestY, minLen, maxLen, step)
        testY = testY.reshape(-1, 1)
        testPred = testPred.reshape(-1, 1)
        print("testY", testY.shape)
        print("testPred", testPred.shape)

    # 还原数据
    testPred = scaler.inverse_transform(testPred)
    testY = scaler.inverse_transform(testY)
    
    trainPred = scaler.inverse_transform(trainPred)
    trainY = util.transform_groundTruth(vtrainY, minLen, maxLen, step)#转换训练集（如果使用变长采样，需要用到该行）
    trainY = trainY.reshape(-1, 1)
    trainY = scaler.inverse_transform(trainY)
    
           
    for i in range(len(testY)):
        dataframe1 = pd.DataFrame({'testY':testY[i],'testPred':testPred[i]})
        dataframe1.to_csv(r"./data/LSTM.csv", mode = 'a', sep=',')

   
    

    plt.figure(figsize=(16, 8))
    plt.xticks(fontsize=22)
    plt.yticks(fontsize=22)
   
    
    plt.xlabel(u"Number of Samples", size=28) #x轴标签
    plt.ylabel("Free Physical Memory (x10 Mb)",size=28) #Y轴标签
    plt.plot([x for x in trainY],c='b', linewidth=1)
    plt.plot([x for x in trainPred],c='g', linewidth=3)
    plt.plot([None for _ in trainY]+[x for x in testY],c='b', linewidth=1)
    plt.plot([None for _ in trainPred]+[x for x in testPred],c='r', linewidth=3)


    # 评估指标
    MAE = eval.calcMAE(testY, testPred)
    print(MAE)
    MRSE = eval.calcRMSE(testY, testPred)
    print(MRSE)
    MAPE = eval.calcMAPE(testY, testPred)
    print(MAPE)
    SMAPE = eval.calcSMAPE(testY, testPred)
    print(SMAPE)

    #util.plot(trainPred,trainY,testPred,testY)

    return trainPred, testPred, MAE, MRSE, SMAPE

def RNN_forecasting1(dataset, lookBack, lr, inputDim=1, hiddenNum=64, outputDim=1, unit="LSTM", epoch=20,
                    batchSize=30, varFlag=False, minLen=15, maxLen=30, step=5):

    # 归一化数据
    scaler = MinMaxScaler(feature_range=(0, 1))
    dataset = scaler.fit_transform(dataset)

    # 分割序列为样本,并整理成RNN的输入形式
    train, test = util.divideTrainTest(dataset)
    
 

    trainX = None
    trainY = None
    vtrainX = None
    vtrainY = None
    testX = None
    testY = None
    vtestX = None
    vtestY = None

    # 构建模型并训练
    RNNModel = RNNs.RNNsModel(inputDim, hiddenNum, outputDim, unit, lr)
    print ("model:", inputDim, outputDim)
    if varFlag:
        vtrainX, vtrainY = util.createVariableDataset(train, minLen, maxLen, step)
        vtestX, vtestY = util.createVariableDataset(test, minLen, maxLen, step)
        print("trainX shape is", vtrainX.shape)
        print("trainY shape is", vtrainY.shape)
        print("testX shape is", vtestX.shape)
        print("testY shape is", vtestY.shape)
        RNNModel.train(vtrainX, vtrainY, epoch, batchSize)
    else:
        trainX, trainY = util.createSamples(train, lookBack)
        testX, testY = util.createSamples(test, lookBack)
        print("trainX shape is", trainX.shape)
        print("trainY shape is", trainY.shape)
        print("testX shape is", testX.shape)
        print("testY shape is", testY.shape)
        RNNModel.train(trainX, trainY, epoch, batchSize)

    # 预测
    if varFlag:
        trainPred = RNNModel.predictVarLen(vtrainX, minLen, maxLen, step)
        testPred = RNNModel.predictVarLen(vtestX, minLen, maxLen, step)
        trainPred= trainPred.reshape(-1, 1)
    else:
        trainPred = RNNModel.predict(trainX)
        testPred = RNNModel.predict(testX)
        trainPred = trainPred.reshape(-1, 1)

    if varFlag:
        # 转化一下test的label
        testY = util.transform_groundTruth(vtestY, minLen, maxLen, step)
        testY = testY.reshape(-1, 1)
        testPred = testPred.reshape(-1, 1)
        print("testY", testY.shape)
        print("testPred", testPred.shape)

    # 还原数据
    testPred = scaler.inverse_transform(testPred)
    testY = scaler.inverse_transform(testY)
    
    trainPred = scaler.inverse_transform(trainPred)
    trainY = util.transform_groundTruth(vtrainY, minLen, maxLen, step)#转换训练集（如果使用变长采样，需要用到该行）
    trainY = trainY.reshape(-1, 1)
    trainY = scaler.inverse_transform(trainY)
    
           
    for i in range(len(testY)):
        dataframe1 = pd.DataFrame({'testY':testY[i],'testPred':testPred[i]})
        dataframe1.to_csv(r"./data/LSTM.csv", mode = 'a', sep=',')

   
    

    plt.figure(figsize=(16, 8))
    plt.xticks(fontsize=22)
    plt.yticks(fontsize=22)
   
    
    plt.xlabel(u"Number of Samples", size=28) #x轴标签
    #plt.ylabel("PSS of system_server (Mb)",size=28) #Y轴标签
    plt.ylabel("Free Physical Memory (x10 Mb)",size=28) #Y轴标签

    plt.plot([x for x in trainY],c='b', linewidth=1)
    plt.plot([x for x in trainPred],c='g', linewidth=3)
    #plt.vlines(191, 0, 95, colors = "k",linewidth=4,linestyles = "dashed")
    plt.plot([None for _ in trainY]+[x for x in testY],c='b', linewidth=1)
    plt.plot([None for _ in trainPred]+[x for x in testPred],c='r', linewidth=3)


    # 评估指标
    MAE = eval.calcMAE(testY, testPred)
    print(MAE)
    MRSE = eval.calcRMSE(testY, testPred)
    print(MRSE)
    MAPE = eval.calcMAPE(testY, testPred)
    print(MAPE)
    SMAPE = eval.calcSMAPE(testY, testPred)
    print(SMAPE)

    #util.plot(trainPred,trainY,testPred,testY)

    return trainPred, testPred, MAE, MRSE, SMAPE

if __name__ == "__main__":

    lag = 24
    batch_size = 32
    epoch = 50
    hidden_dim = 64
    lr = 1e-4
   
    unit1 = "LSTM"
    unit = "GRU"
    
    
    
    ts, data = util.load_data("./data/IoTdata3.csv", columnName="Mem")
    

    trainPred, testPred, mae, mrse, smape = RNN_forecasting(data, lookBack=lag, epoch=epoch, batchSize=batch_size,
                                            varFlag=False, minLen=12, maxLen=24, step=8, unit=unit1, lr=lr)







